import json
import requests
import os
import time
import calendar
import logging
import pandas as pd
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from collections import defaultdict
from azure.storage.blob import BlobServiceClient

logger = logging.getLogger('o9_logger')
pd.options.display.max_columns = None
pd.options.display.max_rows = None
logger.info('Inside DSML Library!')
logger.info(os.environ)
# Set the connection string for the Azure Storage account
connect_str = "DefaultEndpointsProtocol=https;AccountName=miksdatalakestorage;AccountKey=bNListosyqZvtEgaOxaq2ALPeYzUu9Q4TE2QBbqvmCExeN3XhKthFqZU9FsBQ7tnk044mVMiASZrJCgYriF6jg==;EndpointSuffix=core.windows.net"

# Create a BlobServiceClient object using the connection string
blob_service_client = BlobServiceClient.from_connection_string(connect_str)

# Set the name of the container and blob you want to append text to
container_name = "khublogs"
blob_name = "Logs.csv"

# Subscription class
class SubscriptionManagement:
    def __init__(self,Authorization):
        self.Key = Authorization
        
    def GetSubscriptionData(self):
        code = 'ckTvznlv2uq7yf57Aomd_Wsh_tfftejeuXt_YSlMYTE1AzFur2hL8Q=='
        headers = {'x-functions-key':code,'subscriptionKey':self.Key}
        url ="https://miksfunctionapp.azurewebsites.net/api/khubsubscription"
        data = requests.post(url,headers=headers)
        return data
    
    def CreateSubscriptionDict(self,response):
        subscription_dict={}
        if response.status_code ==200:
            data = response.json().get('Data')
            for i in data:
                subscription_dict.update({'Customer':i.get('customer')})
                if subscription_dict.get(i.get('measure_group')) is None:
                    subscription_dict.update({i.get('measure_group'):{i.get('measure'):{'API_Name':i.get('measure_api_name'),'Subscription_information':[{'Country':i.get('country'),'History':i.get('historical_months'),'Future':i.get('future_months')}]}}})
                else:
                    if subscription_dict.get(i.get('measure_group')).get(i.get('measure')) is None:
                        subscription_dict.get(i.get('measure_group')).update({i.get('measure'):{'API_Name':i.get('measure_api_name'),'Subscription_information':[{'Country':i.get('country'),'History':i.get('historical_months'),'Future':i.get('future_months')}]}})
                    else:
                        subscription_dict.get(i.get('measure_group')).get(i.get('measure'))['Subscription_information'].append({'Country':i.get('country'),'History':i.get('historical_months'),'Future':i.get('future_months')})
        return subscription_dict
    

#KnowledgeHub Lib class
class o9KnowledgeHub:
    
    def __init__(self,Authorization,cache_loc = None,tenant_url = None,tenant_key = None,url = 'https://marketintel.trial.o9solutions.com',tenant_name = 'MarketIntel'):
        
        Subscriptions = SubscriptionManagement(Authorization)
        self.sub_data = Subscriptions.GetSubscriptionData()
        self.SubscriptionDict = Subscriptions.CreateSubscriptionDict(Subscriptions.GetSubscriptionData())
        self.Authorization =  "ApiKey "+str(Authorization)
        self.headers = {
                        'Authorization': self.Authorization,
                        'Content-Type': 'application/json'
                    }
        self.payload = {}
        self.cache_loc = cache_loc
        self.tenant_url = tenant_url
        self.tenant_key = tenant_key
        self.globalfilter = None
        # self.base_url = 'https://mysandbox.o9solutions.com'
        self.base_url = url
        self.master_data = requests.get(f'{self.base_url}/api/v2/master/{tenant_name}',headers= self.headers)
        self.att_dim = dict()
        self.DimensionDict = defaultdict(list)
        self.Resource_Dim = dict()
        if self.master_data.status_code == 200:
            for i in self.master_data.json():
                Resource_name = i.get('ResourceName')
                for x in  i.get('KeyAttributes',[]):
                    self.Resource_Dim.update({Resource_name:x.get('DimensionName')})
                    self.DimensionDict[x.get('DimensionName')].append(x.get('Name'))
                    self.att_dim.update({x.get('Name'):x.get('DimensionName')})
        self.fact_data =requests.get(f'{self.base_url}/api/v2/fact/MarketIntel',headers= self.headers)
        self.mg_att = defaultdict(list)
        self.mg_att_name = defaultdict(list)
        self.api_names = dict()
        if self.fact_data.status_code == 200:
            for i in self.fact_data.json():
                for x in  i.get('KeyAttributes',[]):
                    self.mg_att[i.get('ResourceName')].append(x.get('DimensionName'))
                    self.mg_att_name[i.get('ResourceName')].append(x.get("Name"))
                for x in  i.get('DataAttributes',[]):
                    self.api_names.update({x.get('Name'):x.get('ApiName')})
        self.log_service = blob_service_client.get_blob_client(container=container_name, blob=blob_name)      
        
        '''Caching Implementation'''
        
        self.cache = dict()
        self.path = 'KH_Cache1.json'

        if os.environ.get('TENANT_NAME') is None:
            if os.path.isfile(self.path):    
                try:
                    with open(self.path,'r') as cachefile:
                        self.cache = json.load(cachefile)  
                except:
                    pass
        else:
            if self.cache_loc is not None and self.tenant_url is not None and self.tenant_key is not None:
                Cache_URL = f"{self.tenant_url}/api/Upload/Download?fileID={self.cache_loc}"
                try:
                    response = requests.get(Cache_URL, headers={'Authorization': "ApiKey "+self.tenant_key,'Content-Type': 'application/json'})
                    self.cache = response.json()
                except:
                    pass
         
        
        self.default_time=24
        if len(self.att_dim) == 0:
            logger.warning('You may have entered an incorrect or expired API key. Please check your key and try again.')

    def add_filter(self,filters = None):
        if type(filters) == dict:
            self.globalfilter = filters
            
            
    def hash_key(self, val):
        return hash(val)
    
    def add_cache(self, key, val):
        expire = datetime.now() + (timedelta(hours=self.default_time))
        self.cache[key] = expire.strftime("%Y-%m-%d %H:%M:%S.%f"), val.to_json()
        
        
        
    def get_cache(self, key):
        if key in self.cache:
            if datetime.now() < datetime.strptime(self.cache[key][0],"%Y-%m-%d %H:%M:%S.%f"):
                return pd.read_json(self.cache[key][1])
            else:
                self.cache.pop(key)
        return None
    
    def purge_cache(self):
        cache_keys = list(self.cache.keys())
        for key in cache_keys:
            if key in self.cache:
                try:
                    if datetime.now() > datetime.strptime(self.cache[key][0],"%Y-%m-%d %H:%M:%S.%f"):
                        self.cache.pop(key)
                except:
                    pass
            
    def create_filter(self,filter_list,attribute,dimension):
        filter_dict = {
        "IsFilter": True,
        "Axis": "none",
        "AllSelection": False,
        "SelectedMembers": [{"Name":filter_item} for filter_item in filter_list],
        "Name": attribute,
        "DimensionName": dimension
        }
        return filter_dict
    
    def CreatePayload(self,Name,filters): 
    
        '''##BASE PAYLOAD##'''
        
        PayloadDict = {
        "RegularMeasures": [],
        "LevelAttributes": [],
        "DataProperties": {
            "IncludeInactiveMembers": False,
            "IncludeNulls": False,
            "NullsForFinerGrainSelect": False,
            "NullsForUnrelatedAttrSelect": False,
            "RequireEditValidation": False,
            "SubTotalsType": "NoSubtotals",
            "IncludeNullsForSeries": "",
        "MaxRecordLimit": "500000"}}
        
        '''##IF CREATING PAYLOAD FOR DIMENSION##'''
        
        if Name in self.DimensionDict.keys():
            for i in self.DimensionDict.get(Name):
                if i != 'Volcano':
                    PayloadDict['LevelAttributes'].append({"Name":i,"DimensionName":Name,"Axis":"row"})  
        
        
        else:
            '''##IF CREATING PAYLOAD FOR MEASUREGROUP##'''
            
            for i in self.fact_data.json():
                if i.get('ResourceName') == Name:
                    for x in  i.get('KeyAttributes',[]):
                        PayloadDict['LevelAttributes'].append({"Name":x.get('Name'),"DimensionName":x.get('DimensionName'),"Axis":"row"})
                    
                    '''##IF SUPERUSER OR REQUESTING CATALOG DATA##'''
                    
                    if self.SubscriptionDict.get('*') is not None or Name =='CatalogProp':
                        for x in  i.get('DataAttributes',[]):
                            PayloadDict['RegularMeasures'].append({"Name":x.get('Name')})
                        if Name == 'CatalogProp':   
                            Subscription_Request = self.create_requests(Name)
                        else:
                            Subscription_Request = self.create_requests('*')
                        if Subscription_Request is not None:
                            countries  = Subscription_Request.get('requests')[0]['countries'].split('|')
                            HistoryMonth = Subscription_Request.get('requests')[0]['History']
                            FutureMonth = Subscription_Request.get('requests')[0]['Future']
                            
                            if countries[0] != '*' and len(countries)!=0:
                                country_filter = self.create_filter(countries,'Country',self.att_dim.get('Country'))
                                PayloadDict['LevelAttributes'].append(country_filter)
                            
                            
                            if HistoryMonth != '*' and HistoryMonth != 999:
                                today = datetime.now()
                                start_date = today+relativedelta(months=-HistoryMonth)
                                end_date = today+relativedelta(months=+FutureMonth)
                                dates = self.CreateDateRange(start_date,end_date)
                                dates_filter = self.create_filter(dates,'Day',self.att_dim.get('Day'))
                                PayloadDict['LevelAttributes'].append(dates_filter)
                    else:
                        '''##FILTER MEASURES THAT ARE SUBSCRIBED##'''
                        
                        for x in  i.get('DataAttributes',[]):
                            if list(self.SubscriptionDict.get(Name).keys())[0] == '*':
                                PayloadDict['RegularMeasures'].append({"Name":x.get('Name')})
                            elif x.get('Name') in self.SubscriptionDict.get(Name).keys():
                                PayloadDict['RegularMeasures'].append({"Name":x.get('Name')})
                        
                        Subscription_Request = self.create_requests(Name)
                        if Subscription_Request is not None:
                            countries  = Subscription_Request.get('requests')[0]['countries'].split('|')
                            HistoryMonth = Subscription_Request.get('requests')[0]['History']
                            FutureMonth = Subscription_Request.get('requests')[0]['Future']
                            
                            if countries[0] != '*' and len(countries)!=0:
                                country_filter = self.create_filter(countries,'Country',self.att_dim.get('Country'))
                                PayloadDict['LevelAttributes'].append(country_filter)
                            
                            
                            if HistoryMonth != '*' and HistoryMonth != 999:
                                today = datetime.now()
                                start_date = today+relativedelta(months=-HistoryMonth)
                                end_date = today+relativedelta(months=+FutureMonth)
                                dates = self.CreateDateRange(start_date,end_date)
                                dates_filter = self.create_filter(dates,'Day',self.att_dim.get('Day'))
                                PayloadDict['LevelAttributes'].append(dates_filter)
                                
                                
                                
                            
        '''APPLY FILTERS (LOCAL/GLOBAL)'''                    
        if filters is not None:
            processedfilters = self.create_filter_super(filters,Name)
            for eachfilter in processedfilters:
                final_filter = self.create_filter(eachfilter[0],eachfilter[1],eachfilter[2])
                if final_filter.get('Name') == 'Day': 
                    changed = 0
                    for each_dict in PayloadDict['LevelAttributes']:
                        if each_dict.get('IsFilter') and each_dict.get('Name') == final_filter.get('Name'):
                            changed = 1
                            new_member = set([i['Name'] for i in each_dict.get('SelectedMembers')]).intersection(set([i['Name'] for i in final_filter.get('SelectedMembers')]))
                            if len(new_member)!=0:
                                each_dict['SelectedMembers'] = [{'Name':i} for i in new_member]
                            else:
                                each_dict['SelectedMembers'] = [{'Name':'No common member'}]
                    if changed ==0:
                        PayloadDict['LevelAttributes'].append(final_filter)
                        
                elif final_filter.get('Name') == 'Country':
                    changed = 0
                    for each_dict in PayloadDict['LevelAttributes']:
                        if each_dict.get('IsFilter') and each_dict.get('Name') == final_filter.get('Name'):
                            changed = 1
                            new_member = set([i['Name'] for i in each_dict.get('SelectedMembers')]).intersection(set([i['Name'] for i in final_filter.get('SelectedMembers')]))
                            if len(new_member)!=0:
                                each_dict['SelectedMembers'] = [{'Name':i} for i in new_member]
                            else:
                                each_dict['SelectedMembers'] = [{'Name':'No common member'}]
                    if changed ==0:
                        PayloadDict['LevelAttributes'].append(final_filter)
                    
                else:
                    PayloadDict['LevelAttributes'].append(final_filter)
                    
        elif self.globalfilter is not None:
            processedfilters = self.create_filter_super(self.globalfilter,Name)
            for eachfilter in processedfilters:
                final_filter = self.create_filter(eachfilter[0],eachfilter[1],eachfilter[2])
                if final_filter.get('Name') == 'Day': 
                    changed = 0
                    for each_dict in PayloadDict['LevelAttributes']:
                        if each_dict.get('IsFilter') and each_dict.get('Name') == final_filter.get('Name'):
                            changed = 1
                            new_member = set([i['Name'] for i in each_dict.get('SelectedMembers')]).intersection(set([i['Name'] for i in final_filter.get('SelectedMembers')]))
                            if len(new_member)!=0:
                                each_dict['SelectedMembers'] = [{'Name':i} for i in new_member]
                            else:
                                each_dict['SelectedMembers'] = [{'Name':'No common member'}]
                    if changed ==0:
                        PayloadDict['LevelAttributes'].append(final_filter)
                        
                elif final_filter.get('Name') == 'Country':
                    changed = 0
                    for each_dict in PayloadDict['LevelAttributes']:
                        if each_dict.get('IsFilter') and each_dict.get('Name') == final_filter.get('Name'):
                            changed = 1
                            new_member = set([i['Name'] for i in each_dict.get('SelectedMembers')]).intersection(set([i['Name'] for i in final_filter.get('SelectedMembers')]))
                            if len(new_member)!=0:
                                each_dict['SelectedMembers'] = [{'Name':i} for i in new_member]
                            else:
                                each_dict['SelectedMembers'] = [{'Name':'No common member'}]
                    if changed ==0:
                        PayloadDict['LevelAttributes'].append(final_filter)
                    
                else:
                    PayloadDict['LevelAttributes'].append(final_filter)
                
            
                            
            
        # print(PayloadDict)   
        return PayloadDict
    

    #Time Dimension logic
    def CreateDateRange(sself,start_date, end_date):
        delta = end_date-start_date
        dates = []
        for i in range(delta.days + 1):
            day = start_date + timedelta(days=i)
            dates.append(day.strftime('%Y-%m-%d'))
        return dates

    def CreateMonthRange(self,start_date, end_date):
        months = []
        currentdate = start_date
        months.append(currentdate.strftime('%Y-%m-%d'))
        while currentdate < end_date:
            currentdate = currentdate+relativedelta(months=1)
            months.append(currentdate.strftime('%Y-%m-%d'))
        return months


    def CreateQuarterRange(self,start_date, end_date):
        Quarters = []
        currentdate = start_date
        Quarters.append(currentdate.strftime('%Y-%m-%d'))
        while currentdate < end_date:
            currentdate = currentdate+relativedelta(months=3)
            Quarters.append(currentdate.strftime('%Y-%m-%d'))
        return Quarters

    def CreateTimeRange(self,start_date,end_date):
        timerange = []
        current = start_date
        while current < end_date:
            timerange.append(str(current))
            current+=1
        timerange.append(str(current))
        return timerange

    #End of Time dimension logic    


    


    def create_filter_super(self,filters,mgname):
        MGfilters = []
        for key, value in filters.items():
            dimension = str(self.att_dim.get(key))
            #Change it to Time/o9MKTime based on the tenant you are using
            if dimension != 'o9MKTime':
                try:
                    if dimension in self.mg_att.get(mgname) :
                        MGfilters.append([value,key,dimension])
                except:
                    if mgname in self.DimensionDict.keys():
                        if mgname == dimension:
                            MGfilters.append([value,key,dimension])
            else:
                try:
                    if dimension in self.mg_att.get(mgname) :
                        if len(value)==2:
                            if str(key) =='Day':
                                start_date = datetime.strptime(value[0],'%Y-%m-%d')
                                end_date = datetime.strptime(value[1],'%Y-%m-%d')
                                daterange = self.CreateDateRange(start_date,end_date)
                                MGfilters.append([daterange,key,dimension])

                            elif str(key)=='Month':
                                start_date = datetime.strptime(value[0],'%Y-%m-%d')
                                end_date = datetime.strptime(value[1],'%Y-%m-%d')
                                daterange = self.CreateMonthRange(start_date,end_date)
                                MGfilters.append([daterange,key,dimension])

                            elif str(key)=='Quarter':
                                start_date = datetime.strptime(value[0],'%Y-%m-%d')
                                end_date = datetime.strptime(value[1],'%Y-%m-%d')
                                daterange = self.CreateQuarterRange(start_date,end_date)
                                MGfilters.append([daterange,key,dimension])
                            else:
                                start_date = int(value[0])
                                end_date = int(value[1])
                                daterange = self.CreateTimeRange(start_date,end_date)
                                MGfilters.append([daterange,key,dimension])
                except:
                    pass
                    
        return MGfilters
    
    def create_requests(self,mgname):
        data = self.SubscriptionDict.get(mgname)
        if data is not None:
            measurelevel = defaultdict(list)
            for key,value in data.items():
                for y in value['Subscription_information']:
                    measurelevel[key+str(y['History'])+str(y['Future'])].append([key,value['API_Name'],y['Country'],y['History'],y['Future']])
            for key,value in measurelevel.items():
                measurelevel.update({key:[value[0][0],value[0][1],value[0][3],value[0][4],'|'.join(sorted([n[2] for n in value]))]})
            
            measuregrouplevel = defaultdict(list)
            for key,value in measurelevel.items():
                measuregrouplevel[str(value[2])+str(value[3])+str(value[4])].append(value)   
            
            api_requests = {'requests' : []}
            for key,value in measuregrouplevel.items():
                each_req = {'measures':[(measure[0],measure[1]) for measure in value],'History':value[0][2],'Future':value[0][3],'countries':value[0][4]}
                api_requests['requests'].append(each_req)
                
            return api_requests
        
    



    def ParseGetDataResponse(self,response,timekey=False):
        grains = defaultdict(list)
        ColNames = []
        timekeys = {}
        time_attribute = ''
        try:
            for i in response.json()['Meta']:
                ColNames.append(i.get('Name'))
                if i.get('DimensionName') is not None:
                    if i.get('DimensionName') == 'Time':
                        time_dim = 1
                        time_attribute = i.get('AttributeName')
                    else:
                        time_dim = 0
                    for x in i.get('DimensionValues'):
                        grains[i.get('Alias')].append(x.get('Name'))
                        if time_dim == 1:
                            timekeys.update({x.get('Name'):x.get("Key")})
        except:
            pass
                    
        final_value = []
        try:
            for i in response.json()['Data']:
                eachrow = {}
                for x in range(len(grains)):
                    eachrow.update({ColNames[x]:grains.get(str(x))[i[x]]})
                for x in range(len(grains),len(i)):
                    eachrow.update({ColNames[x]:i[x]})

                final_value.append(eachrow)
            if timekey:
                for i in final_value:
                    i.update({"TimeKey":timekeys.get(i[time_attribute])})
        except:
            pass
        if len(final_value)==0:
            logger.warning('Please check your subscription limit!')
        return final_value



    def RequestData(self,Payload,logdata = None,timekey=False):
        
        url = f"{self.base_url}/api/v2/widget/getdata" 
        headers = {
        'Authorization': self.Authorization,
        'Content-Type': 'application/json'
        }
        if len(Payload)!=0:
            payload = json.dumps(Payload)
            response = requests.request("POST", url, headers=headers, data=payload)
            if logdata is not None:
                try:
                    logger.info(logdata)
                    if response.status_code == 200:
                        logdata.append('Success')
                    else:
                        logdata.append('Failed')
                    self.log_request(logdata)
                except:
                    logger.warning('Error While logging to server!')

            ParsedData = self.ParseGetDataResponse(response,timekey)

            DF  = pd.DataFrame(ParsedData)
            grain_cols = []
            measure_cols = []
            for i in DF.columns:
                if i.strip() == 'Version Name':
                    grain_cols.insert(0,i)
                    
                elif i.strip() == 'TimeKey':
                    grain_cols.insert(0,i)
                elif self.att_dim.get(i.strip()) is not None:
                    grain_cols.append(i)
                else:
                    measure_cols.append(i)
            DF = DF[grain_cols+measure_cols]
            DF.rename(columns=self.api_names,inplace=True)
        else:
            DF = pd.DataFrame()
        
        return DF
    


    def get_dim(self,DimensionName,filters=None,caching=True):
        Dimension_name = self.Resource_Dim.get(DimensionName)
        Payload = self.CreatePayload(Dimension_name,filters)
        CacheKey =  json.dumps(Payload)
        if self.get_cache(CacheKey) is not None and caching:
            Result = self.get_cache(CacheKey)
        else:
            Result = self.RequestData(Payload)
            self.add_cache(CacheKey,Result)
            
        if caching:
            self.cache_loc = self.save_cache() 
        return Result

    def get_measuregrp(self,MeasureGroup,filters=None,caching=True,timekey=False):
        if self.create_requests(MeasureGroup) is not None or MeasureGroup =='CatalogProp' or self.SubscriptionDict.get('*') is not None:
            Payload = self.CreatePayload(MeasureGroup,filters)
            CacheKey = json.dumps(Payload)
            if self.get_cache(CacheKey) is not None and caching:
                Result = self.get_cache(CacheKey)
            else:
                st = time.time()
                log_date = time.strftime("%Y-%m-%d %H:%M:%S",time.gmtime(st))
                customer = self.SubscriptionDict.get('Customer')
                if os.environ.get('TENANT_NAME') is not None:
                    Enviroment = os.environ.get('TENANT_NAME')
                    ConnectionType = 'Plugin'
                elif os.environ.get('o9_tenant_name') is not None:
                    Enviroment = os.environ.get('o9_tenant_name')
                    ConnectionType = 'DSML'
                else:
                    Enviroment = 'Local Environment'
                    ConnectionType = 'Library'
                logmeasures = '|'.join([eachmeasure['Name'] for eachmeasure in Payload.get('RegularMeasures')])
                Result = self.RequestData(Payload,logdata=[log_date,customer,Enviroment,logmeasures,ConnectionType],timekey = timekey)
                # Result = self.RequestData(Payload)
                self.add_cache(CacheKey,Result)
        else:
            # print('Measuregroup not subscribed!')
            logger.warning('This MeasureGroup is not subscribed!')
            Result = pd.DataFrame()
            
        if caching:
            self.cache_loc = self.save_cache() 
        return Result   
    
    def log_request(self,data):
        data = ','.join(data)+'\n'
        logger.info('Blob append is calling')
        self.log_service.append_block(data, encoding='utf-8')
    
    def save_cache(self):
        self.purge_cache()
        try:
            with open(self.path,'w') as cachefile:
                json.dump(self.cache,cachefile,default=str)

            if os.environ.get('TENANT_NAME') and self.tenant_url is not None and self.tenant_key is not None:
                updateurl = f"{self.tenant_url}/api/upload/v1/FileUpload/"
                files = {'upload_file': ('KH_Cache1.json', json.dumps(json.load(open('KH_Cache1.json','rb'))),'json')}
                response2 = requests.post(updateurl, headers={'Authorization':"ApiKey "+self.tenant_key},files=files)
                res = response2.json()

                try:
                    ret_var = res.get("files")[0]["fileId"]
                except:
                    ret_var = None
                
                return ret_var
        except:
            pass
        return None

    def get_cache_loc(self):
        return self.cache_loc


    def get_catalog(self,filters = None,caching=True):
        catdim = self.get_dim('Catalog',filters,caching)
        catmg = self.get_measuregrp('CatalogProp',filters,caching) 
        if not catmg.empty:
            catdim.reset_index(drop=True, inplace=True)
            catmg.reset_index(drop=True, inplace=True)
            try:
                finaldf = catdim.merge(catmg, on='ContentItem', how='inner')
            except:
                finaldf = catmg
        else:
            finaldf = catmg
        #vijendra
        # exclude = ['ContentGeoCountry', 'ContentFactor', 'ContentFilter', 'ContentScript', 'ContentSeriesID', 'ContentURL', 'Count']

        exclude = ['ContentGeoCountry', 'ContentFactor', 'ContentFilter', 'ContentMeasureLS', 'ContentScript', 'ContentSeasonalAdjustmentAllowed', 'ContentSeriesID', 'ContentTrendAdjustmentAllowed', 'ContentURL', 'Count']
        finaldf = finaldf[[i for i in finaldf.columns.to_list() if i.strip() not in exclude]]      
        finalcols = ["Version Name"] 
        for i in finaldf.columns:
            if i != "Version Name":
                finalcols.append(i)
        finaldf = finaldf[finalcols]
        return finaldf     
    
    def create_payload_meta(self,Name):
        PayloadDict = {"RegularMeasures": [],
          "LevelAttributes": []}
        key_attribute = []
        data_attribute = []
        
        if Name in self.DimensionDict.keys():
            for i in self.DimensionDict.get(Name):
                if i != 'Volcano':
                    PayloadDict['LevelAttributes'].append({"Name":i,"DimensionName":Name,"Axis":"row"}) 
        
        for i in self.fact_data.json():
            if i.get('ResourceName') == Name:
                for x in  i.get('KeyAttributes',[]):
                    key_attribute.append([x.get('DimensionName'),x.get('Name'),x.get('ApiName')])
                for x in  i.get('DataAttributes',[]):
                    PayloadDict["RegularMeasures"].append({"Name":x.get('Name')})
                    data_attribute.append([x.get('Name'),x.get('ApiName')])

        for i in key_attribute:
            PayloadDict['LevelAttributes'].append({"Name":i[1],"DimensionName":i[0],"Axis":"row"})
            
        return PayloadDict

    def parse_meta(self,response):
        translated_dict = {}
        for i in response.json().get('Meta'):
            if i.get('ToolTip'):
                translated_dict.update({i.get('ApiName'):i.get('ToolTip')})
            else:
                if i.get('ApiName'):
                    translated_dict.update({i.get('ApiName'):i.get('ApiName')})
                else:
                    translated_dict.update({i.get('Name'):i.get('Name')})
        return translated_dict

    def send_request_meta(self,payloaddict):
        url = f"{self.base_url}/api/v2/widget/getmeta" 

        payload = json.dumps(payloaddict)
        headers = {
          'Authorization': self.Authorization,
          'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, data=payload)
        return response

    def get_translated(self,data,MeasureGroup):
        payload = self.create_payload_meta(MeasureGroup)
        meta_dict = self.parse_meta(self.send_request_meta(payload))
        if all([True if x in list(meta_dict.keys()) else False for x in data.columns.to_list()]):
            list1=[]
            list2 =[]
            for i in data.columns.to_list():
                list1.append(i)
                list2.append(meta_dict.get(i))
            translated_data = data.copy(deep = True)
            translated_data .columns=[list1,list2]
            return translated_data 
        else:
            return data
    def get_downloaded(self,data,MeasureGroup):
        payload = self.create_payload_meta(MeasureGroup)
        meta_dict = self.parse_meta(self.send_request_meta(payload))
        meta_dict = {key:value for key,value in meta_dict.items() if key in data.columns.to_list()}
        MetaFrame = pd.DataFrame(list(meta_dict.items()))
        with pd.ExcelWriter(str(MeasureGroup)+"_Data.xlsx") as writer:
            data.to_excel(writer, sheet_name="Data")
            MetaFrame.to_excel(writer, sheet_name="Meta")
            
    def get_subscription(self):
        url = f"{self.base_url}/api/v2/fact/MarketIntel/CatalogProp"
        payload={}
        headers = {
          'Authorization': self.Authorization
        }
        response = requests.request("GET", url, headers=headers, data=payload)
        data = response.json()
        catData = pd.DataFrame(data['Data']['CatalogProps'])
        contentitemdict = {}
        for content in data['Data']['CatalogProps']:
            contentitemdict.update({content['ContentMeasureName']+content['Country']:content['ContentItem']})
        sub_data_list = self.sub_data.json().get('Data')
        for i in sub_data_list:
            try:
                i.update({'description':contentitemdict.get(self.api_names.get(i['measure'])+i['country'])})
            except:
                i.update({'description':None})
            i.update({'measure':self.api_names.get(i.get('measure'))})

        FinalData = pd.DataFrame(sub_data_list)[['customer', 'country', 'measure_group', 'measure','description']]
        FinalData.reset_index(drop=True, inplace=True)

        return FinalData
    
    def closest_day(self,dt, day):
        days_to_day = (day - dt.weekday() + 6) % 7
        delta_past = timedelta(days=7-days_to_day)
        delta_future = timedelta(days=days_to_day)
        past_date = dt - delta_past
        future_date = dt + delta_future

        if delta_past < delta_future:
            return past_date - dt
        else:
            return future_date - dt



    def map_week(self,dataframe, weekkey,targetweekday):
        days_dict = {
        'SUN': 0,
        'MON': 1,
        'TUE': 2,
        'WED': 3,
        'THU': 4,
        'FRI': 5,
        'SAT': 6}
        targetweekday = days_dict.get(targetweekday)
        dataframe[weekkey] = pd.to_datetime(dataframe[weekkey])
        dt = dataframe[weekkey][0]
        dataframe[weekkey] = dataframe.apply(lambda row: row[weekkey]+self.closest_day(dt, targetweekday),axis=1)
        return dataframe

    def convert_to_day(self,df,sourcekey,targetkey,targetmeasure,method):
        df[sourcekey] = pd.to_datetime(df[sourcekey])
        daily_data = pd.DataFrame()
        for i in range(7):
            day = (df[sourcekey] + timedelta(days=i)).dt.date
    #         daily_data = daily_data.append(df[[cols for cols in df.columns.to_list() if cols!=sourcekey]].assign(targetkey=day))
            daily_data = pd.concat([df[[cols for cols in df.columns.to_list() if cols !=sourcekey]].assign(DayKey=(df[sourcekey] + timedelta(days=i)).dt.date) for i in range(7)], ignore_index=True)
        if method == 'SUM':
            daily_data[targetmeasure] = daily_data.apply(lambda row: row[targetmeasure]/7,axis=1)
        daily_data.reset_index(inplace = True)
        daily_data.drop('index',inplace=True,axis=1)
        return daily_data

    def convert_to_month(self,data,sourcekey,targetkey,targetmeasure,method):
        df = data[data.columns.tolist()]
        df[sourcekey] = pd.to_datetime(df[sourcekey])
        df[targetkey] = df[sourcekey].dt.to_period('M').dt.to_timestamp()
        if method == 'SUM':
            monthlydata = df.groupby([cols for cols in df.columns.to_list() if cols !=sourcekey and cols!= targetmeasure])[targetmeasure].sum()
        elif method == 'AVERAGE':
            monthlydata = df.groupby([cols for cols in df.columns.to_list() if cols !=sourcekey and cols!= targetmeasure])[targetmeasure].mean()
        monthlydata_df = monthlydata.reset_index()
        return monthlydata_df

    def week_to_month(self,df,sourcekey,targetkey,targetmeasure,method):
        daydf = self.convert_to_day(df,sourcekey,'DayKey',targetmeasure,method)
        monthdf = self.convert_to_month(daydf,'DayKey',targetkey,targetmeasure,method)
        return monthdf


    def expand_month(self,row,sourcekey,targetmeasure,method):
        month = row[sourcekey].month
        year = row[sourcekey].year
        days_in_month = calendar.monthrange(year, month)[1]
        days = pd.date_range(start=row[sourcekey], periods=days_in_month, freq='D')
        datadict = {}
        for name,value in row.items():
            if name!=sourcekey:
                if name == targetmeasure and method == 'SUM':
                    datadict.update({name:value/days_in_month})
                else:
                    datadict.update({name:value})
        datadict.update({'DayKey': days})
        return pd.DataFrame(datadict)

    def convert_to_week(self,df,sourcekey,targetkey,weekstart,targetmeasure,method):
        df[sourcekey] = pd.to_datetime(df[sourcekey])
        df[targetkey] = df[sourcekey].dt.to_period(f'W-{weekstart}').dt.to_timestamp(how = 'start')-timedelta(days=1)
        if method == 'SUM':
            weeklydata = df.groupby([cols for cols in df.columns.to_list() if cols !=sourcekey and cols!= targetmeasure])[targetmeasure].sum()
        elif method == 'AVERAGE':
            weeklydata = df.groupby([cols for cols in df.columns.to_list() if cols !=sourcekey and cols!= targetmeasure])[targetmeasure].mean()
        weeklydata_df = weeklydata.reset_index()
        return weeklydata_df


    def month_to_week(self,df,sourcekey,targetkey,weekstart,targetmeasure,method):
        df[sourcekey] = pd.to_datetime(df[sourcekey])
        daily_data = pd.concat(df.apply(self.expand_month, axis=1, args=(sourcekey,targetmeasure,method)).values).reset_index()
        daily_data.drop('index',inplace=True,axis=1)
        return self.convert_to_week(daily_data,'DayKey',targetkey,weekstart,targetmeasure,method)
        