from setuptools import setup

setup(name='o9knowledgehub',
      version='2.0.0.1',
      description='Package to pull Knowledge stream data as a dataframe via Knowledge Hub API',
      author='Knowledge Hub ',
      license='o9',
      packages=['o9knowledgehub'],
      zip_safe=False)
